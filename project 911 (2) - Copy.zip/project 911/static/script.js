document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }

    // Get user's tasks
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    let tasks = currentUser.tasks || [];

    const taskForm = document.getElementById('task-form');
    const taskInput = document.getElementById('task-input');
    const prioritySelect = document.getElementById('priority-select');
    const taskList = document.getElementById('task-list');
    const filterButtons = document.querySelectorAll('.filter-btn');
    const completedCount = document.getElementById('completed-count');
    const remainingCount = document.getElementById('remaining-count');
    const progressBar = document.getElementById('progress-bar');

    // Render tasks on page load
    renderTasks();

    // Add new task
    taskForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const taskText = taskInput.value.trim();
        const priority = prioritySelect.value;
        
        if (taskText) {
            const newTask = {
                id: Date.now(),
                text: taskText,
                priority: priority,
                completed: false
            };
            
            tasks.push(newTask);
            saveTasks();
            renderTasks();
            taskInput.value = '';
        }
    });

    // Filter tasks
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            const filter = this.getAttribute('data-filter');
            renderTasks(filter);
        });
    });

    // Render tasks based on filter
    function renderTasks(filter = 'all') {
        taskList.innerHTML = '';
        
        let filteredTasks = tasks;
        if (filter !== 'all') {
            filteredTasks = tasks.filter(task => task.priority === filter);
        }
        
        if (filteredTasks.length === 0) {
            const noTasksItem = document.createElement('li');
            noTasksItem.textContent = filter === 'all' ? 'No tasks yet. Add your first frog!' : `No ${getPriorityLabel(filter)} tasks.`;
            noTasksItem.style.textAlign = 'center';
            noTasksItem.style.padding = '20px';
            noTasksItem.style.color = 'var(--medium-gray)';
            taskList.appendChild(noTasksItem);
        } else {
            filteredTasks.forEach(task => {
                const taskItem = document.createElement('li');
                taskItem.className = `task-item ${task.priority}`;
                taskItem.dataset.id = task.id;
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'task-checkbox';
                checkbox.checked = task.completed;
                checkbox.addEventListener('change', function() {
                    toggleTaskComplete(task.id);
                });
                
                const taskText = document.createElement('span');
                taskText.className = 'task-text';
                taskText.textContent = task.text;
                if (task.completed) {
                    taskText.classList.add('completed');
                }
                
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'delete-btn';
                deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
                deleteBtn.addEventListener('click', function() {
                    deleteTask(task.id);
                });
                
                taskItem.appendChild(checkbox);
                taskItem.appendChild(taskText);
                taskItem.appendChild(deleteBtn);
                
                taskList.appendChild(taskItem);
            });
        }
        
        updateStats();
    }

    // Toggle task completion status
    function toggleTaskComplete(id) {
        tasks = tasks.map(task => {
            if (task.id === id) {
                return { ...task, completed: !task.completed };
            }
            return task;
        });
        saveTasks();
        renderTasks(document.querySelector('.filter-btn.active').getAttribute('data-filter'));
    }

    // Delete task
    function deleteTask(id) {
        tasks = tasks.filter(task => task.id !== id);
        saveTasks();
        renderTasks(document.querySelector('.filter-btn.active').getAttribute('data-filter'));
    }

    // Save tasks to localStorage
    function saveTasks() {
        if (userIndex !== -1) {
            users[userIndex].tasks = tasks;
            localStorage.setItem('users', JSON.stringify(users));
            
            // Update current user in localStorage
            const updatedUser = users[userIndex];
            localStorage.setItem('currentUser', JSON.stringify(updatedUser));
        }
    }

    // Update stats and progress bar
    function updateStats() {
        const totalTasks = tasks.length;
        const completedTasks = tasks.filter(task => task.completed).length;
        const remainingTasks = totalTasks - completedTasks;
        
        completedCount.textContent = completedTasks;
        remainingCount.textContent = remainingTasks;
        
        const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
        progressBar.style.width = `${progress}%`;
    }

    // Helper function to get priority label
    function getPriorityLabel(priority) {
        switch(priority) {
            case 'high': return 'Big Frog';
            case 'medium': return 'Medium';
            case 'low': return 'Tadpole';
            default: return '';
        }
    }
});