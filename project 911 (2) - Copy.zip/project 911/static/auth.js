document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in when accessing dashboard
    if (window.location.pathname.includes('dashboard.html')) {
        checkAuth();
    }

    // Login form handler
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const msgDiv = document.getElementById('loginMessage');

            if (!username || !password) {
                msgDiv.textContent = 'Please fill in all fields';
                msgDiv.style.color = 'red';
                return;
            }

            msgDiv.textContent = 'Logging in...';
            msgDiv.style.color = '#fff';
            try {
                const res = await fetch('/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password })
                });
                const data = await res.json();
                if (res.ok) {
                    localStorage.setItem('currentUser', JSON.stringify({ username }));
                    window.location.href = '/dashboard';
                } else {
                    msgDiv.textContent = data.error || 'Login failed';
                    msgDiv.style.color = 'red';
                }
            } catch (err) {
                msgDiv.textContent = 'Network error. Please try again.';
                msgDiv.style.color = 'red';
            }
        });
    }

    // Signup form handler
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const msgDiv = document.getElementById('signupMessage');

            if (!username || !password) {
                msgDiv.textContent = 'Please fill in all fields';
                msgDiv.style.color = 'red';
                return;
            }

            msgDiv.textContent = 'Signing up...';
            msgDiv.style.color = '#fff';
            try {
                const res = await fetch('/signup', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password })
                });
                const data = await res.json();
                if (res.ok) {
                    localStorage.setItem('currentUser', JSON.stringify({ username }));
                    window.location.href = '/dashboard';
                } else {
                    msgDiv.textContent = data.error || 'Signup failed';
                    msgDiv.style.color = 'red';
                }
            } catch (err) {
                msgDiv.textContent = 'Network error. Please try again.';
                msgDiv.style.color = 'red';
            }
        });
    }

    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            localStorage.removeItem('currentUser');
            window.location.href = '/login';
        });
    }

    // Display current user email in dashboard
    const userEmailElement = document.getElementById('usernameDisplay');
    if (userEmailElement) {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser) {
            userEmailElement.textContent = currentUser.username;
        }
    }

    // Task management synced with backend
    if (window.location.pathname.includes('dashboard.html')) {
        const taskForm = document.getElementById('addTaskForm');
        const taskInput = document.getElementById('newTaskTitle');
        const taskPriority = document.getElementById('taskPriority');
        const taskDueDate = document.getElementById('taskDueDate');
        const tasksCarousel = document.getElementById('tasksCarousel');
        let tasks = [];

        async function fetchTasks() {
            const currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (currentUser) {
                const res = await fetch(`/tasks?username=${currentUser.username}`);
                const data = await res.json();
                tasks = data.tasks;
                renderTasks();
            }
        }

        function saveTasks() {
            const currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (currentUser) {
                tasks.forEach(task => {
                    fetch(`/tasks/${task._id}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(task)
                    });
                });
            }
        }

        function getPriorityBadge(priority) {
            if (priority === 'high') return '<span class="priority-badge priority-high">Big Frog</span>';
            if (priority === 'medium') return '<span class="priority-badge priority-medium">Medium</span>';
            return '<span class="priority-badge priority-low">Tadpole</span>';
        }

        function isOverdue(dueDate, completed) {
            if (!dueDate || completed) return false;
            const today = new Date();
            const due = new Date(dueDate);
            return due < today.setHours(0,0,0,0);
        }

        function renderTasks() {
            tasksCarousel.innerHTML = '';
            tasks.forEach(task => {
                const overdue = isOverdue(task.dueDate, task.completed);
                const card = document.createElement('div');
                card.className = 'netflix-task-card fade-in';
                card.dataset.priority = task.priority || 'low';
                card.innerHTML = `
                    <input type="checkbox" ${task.completed ? 'checked' : ''} data-id="${task._id}" style="margin-bottom:10px;">
                    ${getPriorityBadge(task.priority)}
                    <div class="task-title" style="font-weight:700; font-size:1.1em; margin-bottom:8px;">${task.title}</div>
                    ${task.dueDate ? `<div style="font-size:0.98em;${overdue ? 'color:#e50914;font-weight:700;' : 'color:#bbb;'}">${overdue ? 'Overdue: ' : 'Due: '}${task.dueDate}</div>` : ''}
                    <button class="delete-btn" data-id="${task._id}" style="margin-top:12px;">Delete</button>
                `;
                tasksCarousel.appendChild(card);
            });
            addEventListeners();
        }

        function addEventListeners() {
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', async function(e) {
                    const card = btn.closest('.netflix-task-card');
                    card.classList.add('fade-out');
                    setTimeout(async () => {
                        const taskId = e.target.getAttribute('data-id');
                        await fetch(`/tasks/${taskId}`, { method: 'DELETE' });
                        tasks = tasks.filter(t => t._id !== taskId);
                        renderTasks();
                    }, 300);
                });
            });
            document.querySelectorAll('.netflix-task-card input[type="checkbox"]').forEach(cb => {
                cb.addEventListener('change', async function(e) {
                    const taskId = e.target.getAttribute('data-id');
                    const task = tasks.find(t => t._id === taskId);
                    task.completed = e.target.checked;
                    await fetch(`/tasks/${taskId}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(task)
                    });
                    renderTasks();
                });
            });
        }

        if (taskForm) {
            taskForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                const title = taskInput.value.trim();
                const priority = taskPriority.value;
                const dueDate = taskDueDate.value;
                if (title) {
                    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
                    const res = await fetch('/tasks', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username: currentUser.username, title, priority, dueDate })
                    });
                    const data = await res.json();
                    tasks.push(data.task);
                    renderTasks();
                    // Animate the last card
                    const cards = document.querySelectorAll('.netflix-task-card');
                    if (cards.length) {
                        cards[cards.length-1].classList.add('pop-in');
                    }
                    taskInput.value = '';
                    taskDueDate.value = '';
                }
            });
        }

        fetchTasks();
    }

    function checkAuth() {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (!currentUser) {
            window.location.href = '/login';
        }
    }
});