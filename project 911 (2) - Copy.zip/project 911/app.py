from flask import Flask, request, jsonify, render_template, send_from_directory, redirect, url_for
from flask_cors import CORS
from pymongo import MongoClient
from bson import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)  # Enable CORS for frontend requests

client = MongoClient("mongodb://localhost:27017/")
db = client['frogdb']
users_collection = db['users']
tasks_collection = db['tasks']

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signup')
def signup_page():
    return render_template('signup.html')

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/dashboard')
def dashboard_page():
    user = request.args.get('username') or None
    return render_template('dashboard.html', username=user)

@app.route('/logout')
def logout():
    return redirect(url_for('login_page'))

@app.route('/static/<path:filename>')
def static_files(filename):
    static_folder = app.static_folder or 'static'
    return send_from_directory(static_folder, filename)

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    print('Signup attempt:', username, password)
    if not username or not password:
        return jsonify({'error': 'Missing fields'}), 400
    existing_user = users_collection.find_one({'username': username})
    print('Existing user:', existing_user)
    if existing_user:
        return jsonify({'error': 'Username already exists'}), 409
    users_collection.insert_one({'username': username, 'password': password})
    print('User created:', username)
    return jsonify({'message': 'User created successfully'}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    print('Login attempt:', username, password)
    user = users_collection.find_one({'username': username, 'password': password})
    print('User found:', user)
    if not username or not password:
        return jsonify({'error': 'Missing fields'}), 400
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    return jsonify({'message': 'Login successful', 'username': user['username']}), 200

@app.route('/tasks', methods=['GET'])
def get_tasks():
    username = request.args.get('username')
    if not username:
        return jsonify({'error': 'Missing username'}), 400
    tasks = list(tasks_collection.find({'username': username}))
    for t in tasks:
        t['_id'] = str(t['_id'])
    return jsonify({'tasks': tasks})

@app.route('/tasks', methods=['POST'])
def add_task():
    data = request.json
    username = data.get('username')
    title = data.get('title')
    priority = data.get('priority')
    dueDate = data.get('dueDate', '')
    if not username or not title or not priority:
        return jsonify({'error': 'Missing fields'}), 400
    task = {
        'username': username,
        'title': title,
        'priority': priority,
        'dueDate': dueDate,
        'completed': False
    }
    result = tasks_collection.insert_one(task)
    task['_id'] = str(result.inserted_id)
    return jsonify({'task': task}), 201

@app.route('/tasks/<task_id>', methods=['PUT'])
def update_task(task_id):
    data = request.get_json()
    updates = {}
    if 'title' in data:
        updates['title'] = data['title']
    if 'completed' in data:
        updates['completed'] = data['completed']
    if 'priority' in data:
        updates['priority'] = data['priority']
    if not updates:
        return jsonify({'error': 'No updates provided'}), 400
    result = tasks_collection.update_one({'_id': ObjectId(task_id)}, {'$set': updates})
    if result.matched_count == 0:
        return jsonify({'error': 'Task not found'}), 404
    return jsonify({'message': 'Task updated'})

@app.route('/tasks/<task_id>', methods=['DELETE'])
def delete_task(task_id):
    result = tasks_collection.delete_one({'_id': ObjectId(task_id)})
    if result.deleted_count == 0:
        return jsonify({'error': 'Task not found'}), 404
    return jsonify({'message': 'Task deleted'})

if __name__ == '__main__':
    app.run(debug=True)